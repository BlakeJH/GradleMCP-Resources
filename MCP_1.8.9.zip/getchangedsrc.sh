#!/bin/bash
python runtime/getchangedsrc.py "$@"
